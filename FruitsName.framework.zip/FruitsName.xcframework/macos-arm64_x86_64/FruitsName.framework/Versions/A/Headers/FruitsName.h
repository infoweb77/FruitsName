//
//  FruitsName.h
//  FruitsName
//
//  Created by alex on 23.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for FruitsName.
FOUNDATION_EXPORT double FruitsNameVersionNumber;

//! Project version string for FruitsName.
FOUNDATION_EXPORT const unsigned char FruitsNameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FruitsName/PublicHeader.h>


